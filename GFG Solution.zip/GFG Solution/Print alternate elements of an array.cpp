//User function Template for C++

// ar[] is the array 
// n is the number of elements in array.
void print(int ar[], int n)
{
    for(int i=0;i<n;i=i+2){
        cout<<ar[i]<<" ";
    }
    // code here
    
    
}