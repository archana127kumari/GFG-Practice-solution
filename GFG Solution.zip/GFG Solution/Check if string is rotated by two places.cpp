class Solution
{
    public:
    //Function to check if a string can be obtained by rotating
    //another string by exactly 2 places.
    bool isRotated(string a, string b)
    {
        // Your code here
        if(a.size()==1) return (a==b);
        a+=a;
        return (a.find(b)==2 || a.find(b)==b.size()-2);
    }

};