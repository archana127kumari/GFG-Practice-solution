//{ Driver Code Starts
#include<bits/stdc++.h>
using namespace std;
void printPat(int n);

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
	int n;
	cin>>n;
    printPat(n);
    cout<<endl;
	}
}
// } Driver Code Ends




/*You are required to complete this method*/
void printPat(int n)
{
//Your code here
int ans = n;
   
   while(n>0){
       for(int j = ans; j > 0; j--){
           for(int i = 1; i<= n; i++){
               cout << j << " ";
           }
       }
       cout<< "$";
       n--;
   }

}