/*Structure of the linked list node is as
struct Node {
  int data;
  struct Node * next;
  Node(int x) {
    data = x;
    next = NULL;
  }
}; */

class Solution{
  public:
    Node *insertAtBegining(Node *head, int x) {
       // Your code here
       Node* temp = new Node(x);
       temp -> next = head;
       head = temp;
    }
    
    
    //Function to insert a node at the end of the linked list.
    Node *insertAtEnd(Node* head, int x)  {
       // Your code here
       Node* curr = head;
       Node* temp = new Node(x);
       if(head == NULL){
           return temp;
       }
       while(curr != NULL && curr -> next != NULL){
           curr = curr -> next;
       }
       curr -> next = temp;
       return head;
    }
};