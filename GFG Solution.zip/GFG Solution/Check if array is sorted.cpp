// User function template for C++

class Solution {
  public:
    bool arraySortedOrNot(int arr[], int n) {
        // code here
        
        for(int i=0;i+1<n;i++){
            if(arr[i]>arr[i+1]){
                return false;
            }
        }
      return true;

    }
};