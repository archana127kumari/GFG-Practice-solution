//{ Driver Code Starts
#include <bits/stdc++.h>
using namespace std;


// } Driver Code Ends
class Solution
{
    public:
    //Function is to check whether two strings are anagram of each other or not.
    bool isAnagram(string a, string b){
        
        // Your code here
        sort(a.begin(),a.end());
        sort(b.begin(),b.end());
 
   int i=0;
   int j=0;
   
   while(i<a.size() && j<b.size())
   {
       if(a[i]!=b[i])
       {
           return false;
       }
       i++;
       j++;
   }
     while(i<a.size())
     {
         return false;
     }
  while(i<b.size())
     {
         return false;
     }
     return true;
    }
};


//{ Driver Code Starts.

int main() {
    
    int t;

    cin >> t;

    while(t--){
        string c, d;

        cin >> c >> d;
        Solution obj;
        if(obj.isAnagram(c, d)) cout << "YES" << endl;
        else cout << "NO" << endl;
    }

}

// } Driver Code Ends