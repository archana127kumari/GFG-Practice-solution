
const unsigned int M = 1000000007;
class Solution{
    public:
    int Maximize(int a[],int n)
    {
        // Complete the function
        long long sum=0;
        sort(a,a+n);
        for(long long int  i=0;i<n;i++){
            sum+=a[i]*i;
            sum=sum%M;
        }
        return sum;
    }
};