

class Solution
{
    public:
    //Function to find the maximum occurring character in a string.
    char getMaxOccuringChar(string str)
    {
        // Your code here
         unordered_map<char,int>mp;
        int max_cnt=0;
        char ans;
        sort(str.begin(),str.end());
        for(int i=0;i<str.size();i++){
            mp[str[i]]++;
            if(mp[str[i]]>max_cnt){
                ans=str[i];
                max_cnt=mp[str[i]];
            }
        }
        return ans;
        
    }

};