//User function template for C++
class Solution{
public:	
	// Function to check if array has 2 elements
	// whose sum is equal to the given value
	bool hasArrayTwoCandidates(int arr[], int n, int x) {
	    // code here
	    sort(arr , arr+n);
        int i = 0;
        int j = n-1;
        while(i<j){
            int ans = arr[i] + arr[j];
            if(ans == x){
                return true;
            }
            else if(ans > x){
                j--;
            }
            else{
                i++;
            }
        }
        return false;
    
	}
};