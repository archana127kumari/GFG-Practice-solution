// User function template for C++

class Solution {
  public:
    // Function to return the count of the number of elements in
    // the intersection of two arrays.
    int NumberofElementsInIntersection(int a[], int b[], int n, int m) {
        // Your code goes here
        unordered_map<int,int>mp;
      unordered_set<int>set;
      for(int i=0;i<n;i++)
      {
          mp[a[i]]++;
      }
      for(int i=0;i<m;i++)
      {
          if(mp.find(b[i])!=mp.end())
          set.insert(b[i]);
      }
      return set.size();
    }
    
};