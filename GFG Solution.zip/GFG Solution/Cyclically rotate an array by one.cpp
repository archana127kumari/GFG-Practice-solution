

//User function Template for C++

void rotate(int arr[], int n)
{
        rotate(arr, arr+n-1, arr+n);

}