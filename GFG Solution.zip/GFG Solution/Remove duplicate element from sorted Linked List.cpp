

/*
struct Node {
  int data;
  struct Node *next;
  Node(int x) {
    data = x;
    next = NULL;
  }
};*/

//Function to remove duplicates from sorted linked list.
Node *removeDuplicates(Node *head)
{
 // your code goes here
 Node* tmp=head;
              while(tmp!=NULL && tmp->next!=NULL){
                    if(tmp->data == tmp->next->data){
                      
                      tmp->next=tmp->next->next;
                      
                    }else{
                      tmp=tmp->next;
                    }
              }
              
              return head;
}