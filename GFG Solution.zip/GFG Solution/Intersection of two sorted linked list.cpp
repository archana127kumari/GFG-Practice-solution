

/* The structure of the Linked list Node is as follows:

struct Node
{
    int data;
    Node *next;
    Node(int val)
    {
        data=val;
        next=NULL;
    }
};

*/

Node* findIntersection(Node* head1, Node* head2)
{
    // Your Code Here
    if(head1 == NULL || head2 == NULL){
        return NULL;
    }
    
    Node* ansHead = NULL;
    Node* tail = NULL;
    
    while(head1!=NULL &&head2!=NULL){
        if(head1 -> data == head2 -> data){
            Node* newNode = new Node(head1 -> data);
            if(ansHead == NULL){
                ansHead = newNode;
                tail = newNode;
            }
            else{
                tail -> next = newNode;
                tail = newNode;
            }
            head1 = head1 -> next;
            head2 = head2 -> next;
        }
        else if(head1 -> data < head2 -> data){
            head1 = head1 -> next;
        }
        else{
            head2 = head2 -> next;
        }
    }
    
    return ansHead;

}