//User function template for C++
class Solution{
public:

	void rearrange(int arr[], int n) {
	    // code here
	    vector<int> arr1, arr2;
        
        for(int i=0; i<n; i++) {
            if(arr[i] < 0) {
                arr1.push_back(arr[i]);
            } else {
                arr2.push_back(arr[i]);
            }
        }
        
        int index = 0;
        int i = 0, j = 0;
        
        while(i < arr2.size() && j < arr1.size()) {
            arr[index++] = arr2[i++];
            arr[index++] = arr1[j++];
        }
        
        while(i < arr2.size()) {
            arr[index++] = arr2[i++];
        }
        
        while(j < arr1.size()) {
            arr[index++] = arr1[j++];
        }
    
	}
};