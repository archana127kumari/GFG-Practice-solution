/* The function returns 1 if
IP string is valid else return 0
You are required to complete this method */
class Solution {
    public:
        int isValid(string s) {
            // code here
            
            int count=0;
            int count_dot=0;
            string answer="";
            
            for(int i=0;i<s.size();i++){
                char ch=s[i];
                if(ch!='.'){
                if(ch-'a'>=0 && ch-'a'<=26){
                    return 0;
                }
                answer=answer+ch;
            }
            else{
                count_dot++;
                if(answer==""){
                    return 0;
                }
                if(answer[0]=='0'&& answer.size()>1){
                    return 0;
                }
                int b=stoi(answer);
                if(b>=0 && b<=255){
                    count++;
                }
                else {
                    return 0;
                }
                answer="";
            }
            
            }
            
            if(answer==""){
                return 0;
            }
            if(answer[0]=='0'&& answer.size()>1){
                    return 0;
                }
                int c=stoi(answer);
                if(c>=0 && c<=255){
                    count++;
                }
                if(count==4 && count_dot==3){
                    return 1;
                }
                return 0;
        }
};