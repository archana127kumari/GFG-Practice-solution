/*
The structure of linked list is the following

struct Node {
  int data;
  struct Node *next;
  Node(int x) {
    data = x;
    next = NULL;
  }
};
*/


class Solution
{
    public:
    //Function to remove duplicates from unsorted linked list.
    Node * removeDuplicates( Node *head) 
    {
     // your code goes here
     
     Node* prev=NULL;
     Node* curr=head;
     map<int, bool>visited;
     
     while(curr!=NULL){
         if(visited[curr->data]==true){
             prev->next=curr->next;
             curr->next=NULL;
             delete curr;
             curr=prev->next;
         }else{
             visited[curr->data]=true;
             prev=curr;
             curr=curr->next;
         }
     }
     return head;
    }
};