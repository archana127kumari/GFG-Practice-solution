class Solution{
    public:
    void segregateElements(int arr[],int n)
    {
        // Your code goes here
        int arr1[n];
        int j=0;
        for(int i=0;i<n;i++){
            if(arr[i]>=0){
               arr1[j]=arr[i];
               j++;
            }
        }
        for(int i=0;i<n;i++){
            if(arr[i]<0){
               arr1[j]=arr[i];
               j++;
            }
        }
        for(int i=0;i<n;i++){
            arr[i]=arr1[i];
        }
        
        
    }
};