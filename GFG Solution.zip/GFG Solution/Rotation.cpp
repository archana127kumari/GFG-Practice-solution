//User function template for C++
class Solution{
public:	
	int findKRotation(int arr[], int n) {
	    // code here
	      vector <int> v ;
        for(int i=0; i<n; i++){
            v.push_back(arr[i]);
        }
        sort(v.begin() , v.end());
        int k=0;
        for(int i=0; i<n; i++){
            if(arr[i]==v[0]){
                return k;
             }
             k++;
        }  
        return 0;
	}

};