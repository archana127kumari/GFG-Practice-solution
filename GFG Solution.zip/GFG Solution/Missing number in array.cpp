// User function template for C++

class Solution{
  public:
    int missingNumber(vector<int>& array, int n) {
        // Your code goes here
        int sum=(n*(n+1))/2;
        int arsum=0;
       
        for(int i=0;i<n-1;i++){
            arsum+=array[i];
        }
        int ans=sum-arsum;
        return ans;
        
    }
};