//{ Driver Code Starts
#include <bits/stdc++.h>
using namespace std;

// } Driver Code Ends

class Solution
{
    public:
    //Function to reverse words in a given string.
    string reverseWords(string S) 
    { 
        // code here
        string a ="";
        string ans = "";
        for(int i = S.length()-1; i >=0; i--){
            if(S[i]!='.') {
                a += S[i];
            }
            else{
                reverse(a.begin(), a.end());
                ans += a;
                ans += '.';
                a = "";
            }
            
        }
         reverse(a.begin(), a.end());
            ans+=a;
        return ans;
    } 
};


//{ Driver Code Starts.
int main() 
{
    int t;
    cin >> t;
    while (t--) 
    {
        string s;
        cin >> s;
        Solution obj;
        cout<<obj.reverseWords(s)<<endl;
    }
}
// } Driver Code Ends