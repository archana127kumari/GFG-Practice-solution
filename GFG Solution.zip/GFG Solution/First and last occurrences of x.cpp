class Solution
{
    public:
    vector<int> find(int arr[], int n , int x )
    {
        // code here
        vector<int>v;
   for(int i=0;i<n;i++)
   {
       if(arr[i]==x)
       {
           v.push_back(i);
           break;
       }
   }
   
   for(int i=n-1;i>0;i--)
   {
       if(arr[i]==x)
       {
           v.push_back(i);
           break;
       }
   }
   
   if(v.empty())
   {
       v.push_back(-1);
       v.push_back(-1);
   }
   
   return v;
        
    }
};