class Solution
{
    public:
    //Function to check if two strings are isomorphic.
    bool areIsomorphic(string str1, string str2)
    {
        
        // Your code here
        if(str1.length()!=str2.length())
        return false;
        else
        {
            int a[256]={0};
            int b[256]={0};
            
            for(int i=0;i<str1.length();i++)
            {
                a[str1[i]]+=i+1;
                b[str2[i]]+=i+1;
            }
            
            for(int i=0;i<str1.length();i++)
            {
                if(a[str1[i]]!=b[str2[i]])
                return false;
            }
    
            return true;
            
        }
        
    }
};