class Solution{
public:
    int evenlyDivides(int N){
        //code here
        int b=N;
        int c=0;
        while(N!=0)
        {
            int a=N%10;
            if(a==0)
            {
                a++;
                c--;
            }
            for(int i=a;i<=b;i=i+a)
            {
                
                if(i==b)
                {
                    c++;
                    break;
                }
            }
            N=N/10;
        }
        return c;
    }
};