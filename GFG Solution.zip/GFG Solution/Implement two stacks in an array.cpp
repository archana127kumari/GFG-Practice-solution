



class twoStacks
{
    public:
    
    int *arr;
    int top1;
    int top2;
    int size;
    
    twoStacks()
    {
        size=1000;
        arr=new int[size];
        top1=-1;
        top2=size/2;
        
        
        
    }
 
    void push1(int x)
    {
        if(top1==500) cout<<"stack is full"<<endl;
        arr[++top1]=x;
        
    }
    
    void push2(int x)
    {
        if(top1==1000) cout<<"stack is full"<<endl;
        arr[++top2]=x;
        
       
    }
    
    int pop1()
    {
        if(top1==-1) return -1;
        else {
            int popped=arr[top1];
            top1--;
            return popped;
        }
        
    }
    
    int pop2()
    {
        if(top2==size/2) return -1;
        else {
            int popped=arr[top2];
            top2--;
            return popped;
        }
       
    }
};
