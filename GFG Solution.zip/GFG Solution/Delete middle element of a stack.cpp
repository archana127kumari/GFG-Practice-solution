//User function template for C++

class Solution
{
    public:
    //Function to delete middle element of a stack.
    void deleteMid(stack<int>&s, int sizeOfStack)
    {
        // code here.. 
         int size=s.size();
        
        if(size==(sizeOfStack+1)/2){
            s.pop();
            return;
        }
        
        int temp=s.top();
        s.pop();
        
        deleteMid(s,sizeOfStack);
        
        // backtrack
        s.push(temp);
    }
};