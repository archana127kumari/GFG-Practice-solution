/*
 
  Node is defined as
  struct Node {
    int data;
    struct Node *next;
    Node(int x) {
        data = x;
        next = NULL;
    }
};

*/
class Solution
{
    public:
    //Function to sort a linked list of 0s, 1s and 2s.
    Node* segregate(Node *head) {
        
        // Add code here
        int zero=0;
        int one=0;
        int two=0;
        
        Node* temp = head;

// traverse the LL and count the nos. of 0's, 1's, 2's.


        while(temp != NULL){
            if(temp -> data == 0){
                zero++;
            }
            else if(temp -> data == 1){
                one++;
            }
            else{
                two++;
            }
            temp = temp -> next;
        }
        

temp = head;
// Replace temp data to 0,1,2
        while(temp != NULL){
            if(zero!=0){
                temp -> data = 0;
                zero--;
            }
            else if(one != 0){
                temp -> data = 1;
                one--;
            }
            else if(two != 0){
                temp -> data = 2;
                two--;
            }
            temp = temp -> next;
        }
        return head;
        
    }
};