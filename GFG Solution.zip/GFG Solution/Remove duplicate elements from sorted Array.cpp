//User function template for C++

class Solution{
public:
    int remove_duplicate(int a[],int n){
        // code here
        int i=0;

        for(int j=1;j<n;j++)
        {
            if(a[j]!=a[i]){
                i++;
                a[i]=a[j];
            }
        }
        return i+1;
    }
};