
class Solution
{   
    public:
    //Function to return list of integers that form the boundary 
    //traversal of the matrix in a clockwise manner.
    vector<int> boundaryTraversal(vector<vector<int> > matrix, int n, int m) 
    {
        // code here
        vector<int> v;
        
        if(n==1)//Handles single dimensional arrays(row)
        {
            for(int i=0; i<=m-1; i++)
            {
                v.push_back(matrix[0][i]);
            }
        }
        else if(m==1)//Handles single dimensional arrays(column)
        {
            for(int i=0; i<=n-1; i++)
            {
                v.push_back(matrix[i][0]);
            }
        }
        else//Handles two dimensional arrays
        {
            for(int i=0; i<=m-2; i++)//(0,0) to (0,m-2)
            {
                v.push_back(matrix[0][i]);
            }
            for(int i=0; i<=n-2; i++)//(0,m-1) to (n-2,m-1)
            {
                v.push_back(matrix[i][m-1]);
            }
            for(int i=m-1; i>=1; i--)//(n-1,m-1) to (1,m-1)
            {
                v.push_back(matrix[n-1][i]);
            }
            for(int i=n-1; i>=1; i--)//(n-1,0) to (1,0)
            {
                v.push_back(matrix[i][0]);
            }
        }
        return v;
    }
};