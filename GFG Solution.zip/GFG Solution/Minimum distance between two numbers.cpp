
class Solution{
  public:
    int minDist(int arr[], int n, int x, int y) {
        // code here
        int ans=INT_MAX;
        int a=-1;
        int b=-1;
        
        for(int i=0;i<n;i++){
            if(arr[i]==x)
             a=i;
             
            if(arr[i]==y)
             b=i;
    
        
        if(a!=-1&&b!=-1)
            ans=min(ans,abs(a-b));
        }
        
        return (ans==INT_MAX?-1:ans);
    }
};