
class Solution
{
    public:
    //Function to find the first non-repeating character in a string.
    char nonrepeatingCharacter(string S)
    {
       //Your code here
       unordered_map<char, int> char_count;
    
    // Count the frequency of each character in the string
    for (char c : S) {
        char_count[c]++;
    }
    
    // Iterate through the string again to find the first non-repeating character
    for (char c : S) {
        if (char_count[c] == 1) {
            return c;
        }
    }
    
    // If no non-repeating character is found, return '$'
    return '$';
       
    }

};