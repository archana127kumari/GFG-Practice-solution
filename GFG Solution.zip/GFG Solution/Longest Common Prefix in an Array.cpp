//User function template for C++

class Solution{
  public:
    
    string longestCommonPrefix (string arr[], int N)
    {
        // your code here
       string ans = "";
        
        sort(arr,arr+N);
        int i = 0;
        while(i < arr[0].length() && arr[0][i] == arr[N-1][i]){
            ans+=arr[0][i];
            i++;
        }
        if(ans.size() == 0) return "-1";
        return ans;
    }
};