class Solution{
  public:
    // Function to find floor of x
    // n: size of vector
    // x: element whose floor is to find
    int findFloor(vector<long long> v, long long n, long long x){
        
        // Your code here
        int i=0;
        while(i<n){
            if(x<v[i])
            break;
            i++;
        }
        return i-1;
        
    }
};